#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include <Eigen/Eigen>

void timer_callback();

void traj_gen(const float t);

void state_cb(const nav_msgs::msg::Odometry::SharedPtr msg);

using namespace std::chrono_literals;

std::shared_ptr<rclcpp::Node> controller_node;
rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub;
double period = 0.020; // s
double t;
const double pi = 3.1416;
double kp_pos, ki_pos, kd_pos;
double kp_ang, ki_ang, kd_ang;
double last_dist_err, last_yaw_err, dist_err_int, yaw_err_int;
Eigen::Vector2d pos;
Eigen::Vector2d pos_d;
Eigen::Quaterniond q;

inline void constrain(double &val, double max_val) {
    if (val > max_val)val = max_val;
    else if (val < -max_val)val = -max_val;
}

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    controller_node = std::make_shared<rclcpp::Node>("trajectory_controller");
    controller_node->declare_parameter<double>("kp_pos", 2.0);
    controller_node->declare_parameter<double>("ki_pos", 0.0);
    controller_node->declare_parameter<double>("kd_pos", 0.2);
    controller_node->declare_parameter<double>("kp_ang", 1.5);
    controller_node->declare_parameter<double>("ki_ang", 0.01);
    controller_node->declare_parameter<double>("kd_ang", 0.5);
    cmd_pub = controller_node->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
    auto state_sub = controller_node->create_subscription<nav_msgs::msg::Odometry>("/odom", 10, &state_cb);
    rclcpp::TimerBase::SharedPtr timer = controller_node->create_wall_timer(
            std::chrono::milliseconds(int(period * 1e3)), &timer_callback);
    rclcpp::spin(controller_node);
    rclcpp::shutdown();
    return 0;
}

void timer_callback() {
    kp_pos = controller_node->get_parameter("kp_pos").get_value<double>();
    ki_pos = controller_node->get_parameter("ki_pos").get_value<double>();
    kd_pos = controller_node->get_parameter("kd_pos").get_value<double>();
    kp_ang = controller_node->get_parameter("kp_ang").get_value<double>();
    ki_ang = controller_node->get_parameter("ki_ang").get_value<double>();
    kd_ang = controller_node->get_parameter("kd_ang").get_value<double>();
    traj_gen(t);
    auto pos_err = pos_d - pos;
    auto dist_err = pos_err.norm();
    auto x = q.toRotationMatrix().col(0);
    auto yaw = std::atan2(x(1), x(0));
    auto yaw_d = std::atan2(pos_err(1), pos_err(0));
    auto yaw_err = yaw_d - yaw;
    if (yaw_err > pi)yaw_err -= 2 * pi;
    else if (yaw_err < -pi)yaw_err += 2 * pi;
    RCLCPP_INFO(rclcpp::get_logger("controller"), "[pos err]: x:%.2f,y:%.2f", pos_err(0), pos_err(1));
    RCLCPP_INFO(rclcpp::get_logger("controller"), "[ctrl err]: dist:%.2f,yaw:%.2f", dist_err, yaw_err);
    dist_err_int += (dist_err + last_dist_err) / 2 * period;
    yaw_err_int += (yaw_err + last_yaw_err) / 2 * period;
//    constrain(dist_err_int, 200);
    constrain(yaw_err_int, 2);

    auto vel_linear =
            kp_pos * dist_err + ki_pos * dist_err_int +
            kd_pos * (dist_err - last_dist_err) / period;
    auto vel_angular =
            kp_ang * yaw_err + ki_ang * yaw_err_int +
            kd_ang * (yaw_err - last_yaw_err) / period;
    RCLCPP_INFO(rclcpp::get_logger("controller"), "linear vel cmd:%f,angular vel cmd:%f", vel_linear, vel_angular);
    last_dist_err = dist_err;
    last_yaw_err = yaw_err;
    geometry_msgs::msg::Twist msg;
    msg.linear.x = vel_linear;
    msg.angular.z = vel_angular;
    cmd_pub->publish(msg);
    t += period;
}

void traj_gen(const float t) {
    pos_d(0) = 2;
    pos_d(1) = 3;
}

void state_cb(const nav_msgs::msg::Odometry::SharedPtr msg) {
    pos << msg->pose.pose.position.x, msg->pose.pose.position.y;
    q = Eigen::Quaterniond(msg->pose.pose.orientation.w, msg->pose.pose.orientation.x, msg->pose.pose.orientation.y,
                           msg->pose.pose.orientation.z);
}

