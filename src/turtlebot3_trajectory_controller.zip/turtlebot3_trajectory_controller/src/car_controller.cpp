//
// Created by lay on 23-9-1.
//
#include <string>
#include <chrono>
#include <Eigen/Eigen>
#include <vector>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav_msgs/msg/odometry.hpp"
//#include "geometry_msgs/msg/pose_array.hpp"
#include "gtec_msgs/msg/formation.hpp"
#include "nav_msgs/msg/path.hpp"


using std::placeholders::_1;
using namespace std::chrono_literals;

void limVar(double &x, double xmin, double xmax) {
    if (x < xmin)
        x = xmin;
    else if (x > xmax)
        x = xmax;
}

void get_dist_angle(Eigen::Vector3d &_pos, Eigen::Quaterniond &_q, Eigen::Vector3d &_pos_d, double &_d, double &_thet) {
    auto pos_err = _pos_d.head(2) - _pos.head(2);
    _d = pos_err.norm();
    if (_d > 0.1) {
        auto axisX = _q.toRotationMatrix().col(0);
        auto yaw = std::atan2(axisX(1), axisX(0));
        auto yaw_d = std::atan2(pos_err(1), pos_err(0));
        _thet = yaw_d - yaw;
        if (_thet > M_PI)_thet -= 2 * M_PI;
        else if (_thet < -M_PI)_thet += 2 * M_PI;
    } else
        _thet = 0.0;
}

class PIDController {
public:
    PIDController(double kp, double ki, double kd)
            : kp_(kp), ki_(ki), kd_(kd), integral_(0.0), previous_error_(0.0) {}

    double calculate(double setpoint, double measured_value, double dt) {
        double error = setpoint - measured_value;
        integral_ += error * dt;
        double derivative = (error - previous_error_) / dt;
        double output = kp_ * error + ki_ * integral_ + kd_ * derivative;
        previous_error_ = error;
        return output;
    }

    double calculate(double error, double dt) {
        integral_ += error * dt;
        double derivative = (error - previous_error_) / dt;
        double output = kp_ * error + ki_ * integral_ + kd_ * derivative;
        previous_error_ = error;
        return output;
    }

private:
    double kp_; // Proportional gain
    double ki_; // Integral gain
    double kd_; // Derivative gain

    double integral_;         // Integral term
    double previous_error_;   // Previous error
};

class CarFmtTracker : public rclcpp::Node {
public:
    CarFmtTracker() : Node("car_fmt_tracker"), distController(1, 0, 0),
                      angleController(1, 0, 0) {
        leader_id = 0;
        isLeader = false;
        isPosUpdate = false;
        isLeaderPosUpdate = false;
        isLeaderPathSet = false;
        isFmtSet = false;
        target_node_id = 0;
        last_timestamp = 0;
        yaw = 0;
        yaw_d = 0;
        offset = Eigen::Vector3d(0, 0, 0);
        pos = Eigen::Vector3d(0, 0, 0);
        pos_d = Eigen::Vector3d(0, 0, 0);
        q = Eigen::Quaterniond(1, 0, 0, 0);
        this->declare_parameter<std::string>("namespece", "/scout");
        this->declare_parameter<int>("node_id", 0);
        this->declare_parameter<std::string>("fmt_topic", "/formation");
        this->declare_parameter<std::string>("path_topic", "/path");

        this->get_parameter("namespace", namespace_);
        this->get_parameter("node_id", id);
        this->get_parameter("fmt_topic", fmt_topic);
        this->get_parameter("path_topic", path_topic);

        auto cmd_topic_name = namespace_ + std::to_string(id) + "/cmd_vel";
        auto state_topic_name = namespace_ + std::to_string(id) + "/state_ground_truth";
        cmd_pub = this->create_publisher<geometry_msgs::msg::Twist>(cmd_topic_name, 10);
        fmt_sub = this->create_subscription<gtec_msgs::msg::Formation>(
                fmt_topic, 10, std::bind(&CarFmtTracker::fmt_callback, this, _1));
        vehicle_ground_truth_sub = this->create_subscription<nav_msgs::msg::Odometry>(
                state_topic_name, 10, std::bind(&CarFmtTracker::vehicle_ground_truth_callback, this, _1));
        auto timer_ = this->create_wall_timer(50ms, std::bind(&CarFmtTracker::timer_callback, this));
    }

private:
    void timer_callback();

    void fmt_callback(const gtec_msgs::msg::Formation::SharedPtr msg);

    void leader_ground_truth_callback(const nav_msgs::msg::Odometry::SharedPtr msg);

    void vehicle_ground_truth_callback(const nav_msgs::msg::Odometry::SharedPtr msg);

    void goal_array_callback(const nav_msgs::msg::Path::SharedPtr msg);

    void fmt_track_ctrl() const;

    void publish_velocity_setpoint(double vx, double wz) const;

    uint16_t id;
    uint16_t leader_id;
    bool isLeader;
    bool isPosUpdate;
    bool isLeaderPosUpdate;
    bool isLeaderPathSet;
    bool isFmtSet;
    int target_node_id;
    float last_timestamp;
    double yaw;
    double yaw_d;//unused
    Eigen::Vector3d offset;
    Eigen::Vector3d pos;
    Eigen::Vector3d pos_d;
    Eigen::Quaterniond q;
    std::vector<Eigen::Vector3d> leader_path;
    PIDController distController;
    PIDController angleController;
    std::string namespace_;
    std::string fmt_topic;
    std::string path_topic;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub;
    rclcpp::Subscription<gtec_msgs::msg::Formation>::SharedPtr fmt_sub;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr vehicle_ground_truth_sub;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr leader_ground_truth_sub; //
    rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr leader_path_sub;
};

void CarFmtTracker::timer_callback() {
    if (!isLeader && isLeaderPosUpdate && isPosUpdate) {
        fmt_track_ctrl();
    } else if (isLeader && isLeaderPathSet && isPosUpdate) {
        auto d = pos.head(2) - leader_path[target_node_id].head(2);
        if (d.norm() < 2.0) {
            target_node_id += 1;
        }
        if (target_node_id > leader_path.size() - 1) {
            target_node_id = 0;
        }
        pos_d = leader_path[target_node_id];
        fmt_track_ctrl();
    }
}

//队形订阅回调
void CarFmtTracker::fmt_callback(const gtec_msgs::msg::Formation::SharedPtr msg) {
    {
        leader_id = msg->robotid_list[0];
        if (leader_id == id) {
            isLeader = true;
            if (!isFmtSet) {
                leader_path_sub = this->create_subscription<nav_msgs::msg::Path>(
                        path_topic, 10, std::bind(&CarFmtTracker::goal_array_callback, this, _1));
            }
        } else {
            isLeader = false;
            for (size_t i = 1; i < msg->num_fmt; i++) {
                if (msg->robotid_list[i] == id) {
                    offset << msg->x[i], msg->y[i], msg->z[i];
                    if (!isFmtSet) {
                        auto leader_topic_name = namespace_ + std::to_string(leader_id) + "/state_ground_truth";
                        leader_ground_truth_sub = this->create_subscription<nav_msgs::msg::Odometry>(
                                leader_topic_name, 10,
                                std::bind(&CarFmtTracker::leader_ground_truth_callback, this, _1));
                    }
                    break;
                }
            }
        }
        isFmtSet = true;
    }
}

void CarFmtTracker::leader_ground_truth_callback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    isLeaderPosUpdate = true;
    pos_d(0) = msg->pose.pose.position.x + offset(0);
    pos_d(1) = msg->pose.pose.position.y + offset(1);
    pos_d(2) = msg->pose.pose.position.z + offset(2);
}

void CarFmtTracker::vehicle_ground_truth_callback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    isPosUpdate = true;
    pos << msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z;
    q.coeffs() << msg->pose.pose.orientation.x,
            msg->pose.pose.orientation.y, msg->pose.pose.orientation.z, msg->pose.pose.orientation.w;

}

void CarFmtTracker::goal_array_callback(const nav_msgs::msg::Path::SharedPtr msg) {
    std::vector<std::string> header_path = stringSplit(msg->header.frame_id, '_');
    int robot_type = atoi(header_path[0].c_str());
    int robot_real = atoi(header_path[1].c_str());
    int robot_leader = atoi(header_path[2].c_str());
    if (robot_leader == leader_id && !isLeaderPathSet) {
        for (size_t i = 0; i < msg->poses.size(); i++) {
            auto path_node = Eigen::Vector3d(msg->poses[i].pose.position.x, msg->poses[i].pose.position.y,
                                             msg->poses[i].pose.position.z);
            leader_path.push_back(path_node);
        }
        isLeaderPathSet = true;
    }
}

void CarFmtTracker::fmt_track_ctrl() const {
    double distance;
    double thet;
    auto timestamp = this->get_clock()->now().seconds();
    auto dt = timestamp - last_timestamp;
    last_timestamp = timestamp;

    get_dist_angle(pos, q, pos_d, distance, thet);
    double vxCmd = distController.calculate(distance, dt);
    double wzCmd = angleController.calculate(thet, dt);
    /////////////////////////////////////////////
    limVar(vxCmd, -2, 2);
    limVar(wzCmd, -1, 1);
    publish_velocity_setpoint(vxCmd, wzCmd);
}

void CarFmtTracker::publish_velocity_setpoint(double vx, double wz) const {
    geometry_msgs::msg::Twist msg;
    msg.linear.x = vx;
    msg.angular.z = wz;
    cmd_pub->publish(msg);
}

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CarFmtTracker>());
    rclcpp::shutdown();
    return 0;
}

